(function () {
    var resizeId;
    $(window).resize(function () {
        $('.tanks-item').off('click');
        clearTimeout(resizeId);
        resizeId = setTimeout(doneResizing, 0);
    });

    function doneResizing() {
        Tooltip.initTooltip();
        Tooltip.showTooltip();
    }

    Tooltip.initTooltip();
    Tooltip.showTooltip();

    $('.tooltip').on('click', function (e) {
        e.stopPropagation();
    });

    $('.tanks-item').each(function () {
        initRangeSlider($(this));
    });

    function maxValue(value, min, max) {
        if(parseInt(value) < min || isNaN(parseInt(value))) {
            return '';
        } else if(parseInt(value) > max) {
            return 300;
        } else return value;
    }

    function calculateExperience(el, input) {
        var equipment = el.find('.tooltip-equipment input[type="radio"]:checked').val(),
            fights = input.val(),
            resultOutput = el.find('.experience-value'),
            result;

        switch(equipment) {
            case 'standard':
                result = fights * 3;
                break;
            case 'elite':
                result = fights * 3 * 1.1;
                break;

            case 'premium':
                result = fights * 3 * 1.2;
                break;
        }

        resultOutput.text(Math.ceil(result));
    }

    function initRangeSlider(el) {
        var $slider = el.find('.rangeSlider'),
            $sliderValue = el.find('.rangeSliderValue'),
            $radio = el.find('.tooltip-equipment input[type="radio"]');

        $slider.slider({
            range: 'max',
            min: 0,
            max: 300,
            value: 0,
            slide: function (event, ui) {
                $sliderValue.val(ui.value);
                $(ui.value).val($sliderValue.val());
                // Calculate experience
                calculateExperience(el, $sliderValue);
            }
        });

        $sliderValue.on('keypress', function (e) {
            e = (e) ? e : window.event;
            var charCode = (e.which) ? e.which : e.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
        });

        $sliderValue.keyup(function () {
            var value = $(this).val(),
                newVal = maxValue(value, 0, 300);

            $slider.slider('value', value);
            $(this).val(newVal);
            // Calculate experience
            calculateExperience(el, $sliderValue);
        });

        $radio.on('change', function () {
            if($(this).is(':checked')) {
                // Calculate experience
                calculateExperience(el, $sliderValue);
            }
        })
    }

})();