var Tooltip = (function () {

    var options = {
            rightClass: 'right',
            leftClass: 'left',
            topClass: 'top',
            bottomClass: 'bottom',
            hover: 'tanks-item--hovered'
        };

    function initTooltip() {
        $('.tooltip').each(function(){
            var container = $(this).parents('.tanks'),
                item = $(this).parent('.tanks-item'),
                itemHeight = item.height(),
                containerHeight = container.height(),
                containerWidth = container.width(),
                positionTop = item.position().top,
                positionLeft = item.position().left,
                tooltipHeight = $(this).height(),
                tooltipWidth = $(this).outerWidth();

            if ($(window).width() >= 768) {

                if (containerHeight < (positionTop + itemHeight + tooltipHeight)) {
                    $(this).addClass(options.bottomClass);
                }

                if (containerWidth < (positionLeft + (tooltipWidth / 2))) {
                    $(this).addClass(options.rightClass);
                }

                if ((positionLeft === 0)) {
                    $(this).addClass(options.leftClass);
                }

            }
        });
    }

    function scrollToElement(element, delay) {
        $('body').stop().animate({
            scrollTop: element.offset().top + element.outerHeight() - $(window).height()
        }, delay);
    }

    function showTooltip() {
        $('.tanks-item').on('click', function () {
            var $this = $(this);

            if ($(window).width() < 768) {

                $('.tanks-item').not(this).removeClass(options.hover);

                if ($this.hasClass(options.hover)) {
                    $this.removeClass(options.hover);
                } else {
                    $this.addClass(options.hover);
                    scrollToElement($this.find('.tooltip'), 300);
                }
            } else {
                return false;
            }
        });
    }

    function hideTooltips() {
        $('.tanks-item').removeClass(options.hover);
    }

    return {
        initTooltip: initTooltip,
        showTooltip: showTooltip,
        hideTooltips: hideTooltips
    }
})();

